# Aegis File Organizer for Windows

## Launch the application

Open `dist\Aegis\Aegis.exe`. Python is **not required** on the destination computer.
Keep the entire `Aegis` folder together, including `_internal`; the executable depends on those bundled files.

For convenient access, double-click `Install-Shortcuts.cmd` inside that folder. It creates Desktop and Start-menu shortcuts for your Windows account, without administrator rights. You can then pin Aegis to the taskbar using Windows. Move the application to its permanent location before creating shortcuts; rerun the installer if you move it later. To uninstall, delete the app folder and its two shortcuts. Settings remain in `%LOCALAPPDATA%\Aegis` unless you remove them separately.

To transfer the application to another Windows x64 computer, extract `dist\Aegis-Windows-x64.zip` and open `Aegis\Aegis.exe`. This build targets Windows 10/11 x64. It is unsigned; no code-signing certificate was supplied.

## Which script is packaged?

`agent-2.py` is the main interface: dashboard, preview, manual folder overrides, duplicate review, history, and undo. `main.py` launches it with single-instance protection and diagnostic logging. `agent-1.py` is retained unchanged as the legacy implementation and is not included in the executable. Use the new executable for the hardened move and undo behavior.

The packaged Gemini option now performs naming requests (Agent 2 previously used the offline heuristic even when Gemini was selected). It sends only filenames and website origins after confirmation, not document or image contents. This differs from Agent 1's document/image analysis. The API key stays in memory for the session. Offline Fast Smart is the default and needs no internet or key. Gemini failures fall back to offline naming with a reason shown in the preview. Live paid API calls are not part of the build checks. `AEGIS_GEMINI_MODEL` can override the default `gemini-2.5-flash` model if needed.

## Workflow and safeguards

1. Choose a target folder on the Dashboard.
2. Open Organize Workflow and select Analyze Files.
3. Review the plan; select a file to inspect or override its destination folder.
4. Execute the reviewed plan. Existing destinations and files changed since preview are skipped.
5. Use Action History → Undo Last Local Run to restore the latest run in the selected folder.

Files are moved with Windows same-volume rename; creation/modification timestamps and file metadata are retained without copy-and-delete overhead. Cross-volume moves are rejected. Duplicates are identified by size and streaming SHA-256 and moved to a review folder, never deleted. Temporary download files, symbolic links, application state files, and the running executable are excluded.

Each move has a flushed recovery intent recorded before rename in `.aegis-undo.jsonl` in the selected folder. Undo never overwrites an existing original or restores a file whose size, modification time, or file identity has changed. Conflicts retain the journal for retry. New runs archive the previous journal under `.aegis-history`; the UI restores only the latest run. Legacy scripts' undo logs remain untouched and must be handled with their original versions. Keep recovery files with the organized folder. These identity checks do not replace backups or detect deliberate edits that preserve both size and modification time.

Only one packaged instance runs at a time. File processing runs on a worker, UI updates run on the GUI thread, and normal closing/folder changes are blocked during operations. Settings and history are atomically written to `%LOCALAPPDATA%\Aegis`, independently of the launch directory. Rotating diagnostics are in `aegis.log` in that directory. Old project-local configuration/API keys are not copied into the distributable or automatically migrated.

## Rebuild

Use Windows x64 and Python 3.14 (the supplied build was verified on 3.14.5):

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
```

The script creates an isolated `.venv`, installs the exact dependency versions in `requirements-build.txt`, runs safety tests, builds the app, runs a packaged preview/move/undo smoke test on temporary files, and produces a ZIP. Build outputs are ignored by Git. `requirements.txt` retains the original source/legacy dependencies.

For source development:

```powershell
.\.venv\Scripts\python.exe main.py
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

The folder-based bundle avoids unpacking the Python runtime on every launch and includes CustomTkinter's font/theme assets. See [PyInstaller operating modes](https://pyinstaller.org/en/stable/operating-mode.html) and [CustomTkinter packaging](https://customtkinter.tomschimansky.com/documentation/packaging/). Gemini timeout and client cleanup follow the [Google Gen AI SDK](https://googleapis.github.io/python-genai/).
